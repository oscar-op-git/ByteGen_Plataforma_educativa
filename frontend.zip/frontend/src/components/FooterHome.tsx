import React from 'react'

const FooterHome: React.FC = () => {
  return (
    <footer style={{ textAlign: 'center', marginTop: 24, color: '#6b7280' }}>
      @bytegeneration
    </footer>
  )
}

export default FooterHome
